<!DOCTYPE html>
<html lang="en">

<head>
<!-- HeaderLinks Include Here -->
<?php include 'headlinks.php';?>
<!-- HeaderLinks Include Here -->
</head>

<body>
<!-- Header Include Here -->
<?php include 'header.php';?>
<!-- Header Include Here -->

<!-- Site Loader Start Here -->
<div id="preloader"></div>
<!-- Site Loader End Here -->
</body>
</html>