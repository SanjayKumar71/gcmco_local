<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Site Title -->
<title>Carolyn Gil</title>
<!-- Site Title -->

<!-- Favicon -->
<link rel="icon" type="image/fav.png" href="img/favicon.png">
<!-- Favicon -->

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Bootstrap CSS -->

<!-- Font Awesome CDN -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Font Awesome CDN -->

<!-- Magnific Popup core CSS file -->
<link rel="stylesheet" href="magnific-popup/magnific-popup.css">
<!-- Magnific Popup core CSS file -->

<!-- Slick Slider CDN -->
<link rel="stylesheet" href="slick/slick.css">
<link rel="stylesheet" href="slick/slick-theme.css">
<!-- Slick Slider CDN -->

<!-- Anime.js CDN -->
<link rel="stylesheet" href="css/animate.css">
<!-- Anime.js CDN -->

<!-- Css Stylesheet -->
<link rel="stylesheet" href="css/style.css">
<!-- Css Stylesheet -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bs-stepper@1.3.0/dist/css/bs-stepper.min.css">